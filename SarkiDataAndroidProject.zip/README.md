# SarkiData Android project

A minimal Android WebView wrapper for https://sarki.com.ng with a branded splash screen.

## Included
- App label: SarkiData
- Uses the provided logo asset
- Loads the website inside the app without a browser address bar
- Loading spinner and connection-error message
- Back button navigation
- Only the Android `INTERNET` permission is declared
- Native file/content access is disabled and no file chooser is implemented

## Build an APK from your Android phone using GitHub Actions
1. Sign in or create an account at https://github.com.
2. Create a new repository named `SarkiDataAndroid`.
3. Upload the contents of this folder (not the ZIP itself) to the repository. On GitHub mobile web, use the repository's Add file / Upload files option if available; otherwise use a mobile Git client.
4. The workflow in `.github/workflows/build-apk.yml` runs automatically after you push the files.
5. Open the repository's **Actions** tab, choose the latest **Build SarkiData APK** run, and download the `SarkiData-debug-apk` artifact.
6. Extract the downloaded artifact ZIP and install `app-debug.apk`. Android may ask you to allow installs from your browser or file manager; that is an Android installation setting, not an app permission.

## Notes
- This is a debug APK for testing, not a Play Store release.
- The app needs internet access to display the website. The `INTERNET` permission does not trigger a runtime permission prompt.
- WebView cannot provide a guarantee that every website feature works exactly like a native app. Payments, sign-in, and external links should be tested on-device.
- Website file inputs are not wired to a native chooser. The site itself may still display an upload control, but it won't be connected to a native file picker by this project.
- Before public release, verify that the website owner permits this wrapper and test on the target Android versions.
