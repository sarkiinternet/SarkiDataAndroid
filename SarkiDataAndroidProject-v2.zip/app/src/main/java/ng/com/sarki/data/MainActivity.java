package ng.com.sarki.data;

import android.app.Activity;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://sarki.com.ng/";
    // Website/logo accent is a fresh light green. Adjust this if the site's palette changes.
    private static final int BRAND_GREEN = Color.rgb(166, 230, 95);
    private static final int DARK_TEXT = Color.rgb(28, 35, 28);
    private FrameLayout root;
    private WebView webView;
    private View splash;
    private TextView statusText;
    private boolean pageLoaded = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
                | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                // Keep ordinary web navigation in the app, without showing a browser address bar.
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                if (splash != null) {
                    root.removeView(splash);
                    splash = null;
                }
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame() && !pageLoaded && statusText != null) {
                    statusText.setText("Couldn't load SarkiData. Check your connection and try again.");
                }
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        showSplash();
        webView.loadUrl(HOME_URL);
    }

    private void showSplash() {
        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(Color.WHITE);

        android.widget.LinearLayout content = new android.widget.LinearLayout(this);
        content.setOrientation(android.widget.LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(32, 32, 32, 32);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.sarki_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        android.widget.LinearLayout.LayoutParams logoParams =
                new android.widget.LinearLayout.LayoutParams(220, 220);
        logoParams.bottomMargin = 24;
        content.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("SarkiData");
        title.setTextColor(DARK_TEXT);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, android.graphics.Typeface.BOLD);
        content.addView(title);

        ProgressBar spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        if (android.os.Build.VERSION.SDK_INT >= 21) {
            spinner.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(BRAND_GREEN));
        }
        android.widget.LinearLayout.LayoutParams spinParams =
                new android.widget.LinearLayout.LayoutParams(48, 48);
        spinParams.topMargin = 28;
        content.addView(spinner, spinParams);

        statusText = new TextView(this);
        statusText.setText("Getting things ready…");
        statusText.setTextColor(Color.DKGRAY);
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        android.widget.LinearLayout.LayoutParams statusParams =
                new android.widget.LinearLayout.LayoutParams(
                        ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = 16;
        content.addView(statusText, statusParams);

        layer.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        splash = layer;
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    @Override
    public void onBackPressed() {
        if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
