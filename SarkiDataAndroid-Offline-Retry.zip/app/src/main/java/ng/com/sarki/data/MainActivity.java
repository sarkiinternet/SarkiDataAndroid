package ng.com.sarki.data;

import android.app.Activity;
import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;

public class MainActivity extends Activity {
    private static final String HOME_URL = "https://sarki.com.ng/";
    private static final int BRAND_GREEN = Color.rgb(166, 230, 95);
    private static final int DARK_TEXT = Color.rgb(28, 35, 28);

    private FrameLayout root;
    private WebView webView;
    private View splash;
    private View offlineView;
    private TextView statusText;
    private TextView offlineMessage;
    private ProgressBar spinner;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.WHITE);
        getWindow().setNavigationBarColor(Color.WHITE);
        getWindow().getDecorView().setSystemUiVisibility(
                View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR | View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR);

        root = new FrameLayout(this);
        root.setBackgroundColor(Color.WHITE);
        setContentView(root);

        webView = new WebView(this);
        webView.setBackgroundColor(Color.WHITE);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setAllowFileAccess(false);
        webView.getSettings().setAllowContentAccess(false);
        webView.getSettings().setJavaScriptCanOpenWindowsAutomatically(false);
        webView.getSettings().setSupportMultipleWindows(false);
        webView.setOverScrollMode(View.OVER_SCROLL_NEVER);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                String scheme = request.getUrl().getScheme();
                return !("https".equalsIgnoreCase(scheme) || "http".equalsIgnoreCase(scheme));
            }

            @Override
            public void onPageStarted(WebView view, String url, android.graphics.Bitmap favicon) {
                hideOffline();
            }

            @Override
            public void onPageFinished(WebView view, String url) {
                hideSplash();
            }

            @Override
            public void onReceivedError(WebView view, WebResourceRequest request, WebResourceError error) {
                if (request.isForMainFrame()) {
                    showOffline();
                }
            }
        });

        root.addView(webView, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));

        if (hasNetworkConnection()) {
            showSplash();
            webView.loadUrl(HOME_URL);
        } else {
            showOffline();
        }
    }

    private boolean hasNetworkConnection() {
        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
            if (cm == null) return false;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                Network network = cm.getActiveNetwork();
                if (network == null) return false;
                NetworkCapabilities caps = cm.getNetworkCapabilities(network);
                return caps != null && (
                        caps.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_CELLULAR)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_ETHERNET)
                        || caps.hasTransport(NetworkCapabilities.TRANSPORT_BLUETOOTH)
                        || caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET));
            } else {
                android.net.NetworkInfo info = cm.getActiveNetworkInfo();
                return info != null && info.isConnected();
            }
        } catch (Exception ignored) {
            // If the system can't confirm a connection, still attempt to show a helpful retry screen.
            return true;
        }
    }

    private void showSplash() {
        hideOffline();
        FrameLayout layer = new FrameLayout(this);
        layer.setBackgroundColor(Color.WHITE);

        LinearLayout content = new LinearLayout(this);
        content.setOrientation(LinearLayout.VERTICAL);
        content.setGravity(Gravity.CENTER);
        content.setPadding(32, 32, 32, 32);

        ImageView logo = new ImageView(this);
        logo.setImageResource(R.drawable.sarki_logo);
        logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
        LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(220, 220);
        logoParams.bottomMargin = 24;
        content.addView(logo, logoParams);

        TextView title = new TextView(this);
        title.setText("SarkiData");
        title.setTextColor(DARK_TEXT);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(null, Typeface.BOLD);
        content.addView(title);

        spinner = new ProgressBar(this);
        spinner.setIndeterminate(true);
        if (Build.VERSION.SDK_INT >= 21) {
            spinner.setIndeterminateTintList(android.content.res.ColorStateList.valueOf(BRAND_GREEN));
        }
        LinearLayout.LayoutParams spinParams = new LinearLayout.LayoutParams(48, 48);
        spinParams.topMargin = 28;
        content.addView(spinner, spinParams);

        statusText = new TextView(this);
        statusText.setText("Connecting to SarkiData…");
        statusText.setTextColor(Color.DKGRAY);
        statusText.setTextSize(14);
        statusText.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams statusParams = new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        statusParams.topMargin = 16;
        content.addView(statusText, statusParams);

        layer.addView(content, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        splash = layer;
        root.addView(splash, new FrameLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
    }

    private void hideSplash() {
        if (splash != null) {
            root.removeView(splash);
            splash = null;
        }
    }

    private void showOffline() {
        hideSplash();
        if (offlineView == null) {
            LinearLayout panel = new LinearLayout(this);
            panel.setOrientation(LinearLayout.VERTICAL);
            panel.setGravity(Gravity.CENTER);
            panel.setPadding(32, 40, 32, 40);
            panel.setBackgroundColor(Color.WHITE);

            ImageView logo = new ImageView(this);
            logo.setImageResource(R.drawable.sarki_logo);
            logo.setScaleType(ImageView.ScaleType.FIT_CENTER);
            LinearLayout.LayoutParams logoParams = new LinearLayout.LayoutParams(128, 128);
            logoParams.bottomMargin = 22;
            panel.addView(logo, logoParams);

            TextView heading = new TextView(this);
            heading.setText("You're offline");
            heading.setTextColor(DARK_TEXT);
            heading.setTextSize(24);
            heading.setTypeface(null, Typeface.BOLD);
            heading.setGravity(Gravity.CENTER);
            panel.addView(heading);

            offlineMessage = new TextView(this);
            offlineMessage.setText("Please check your Wi-Fi or mobile data connection, then try again.");
            offlineMessage.setTextColor(Color.rgb(95, 95, 95));
            offlineMessage.setTextSize(16);
            offlineMessage.setGravity(Gravity.CENTER);
            LinearLayout.LayoutParams messageParams = new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT);
            messageParams.topMargin = 12;
            messageParams.bottomMargin = 24;
            panel.addView(offlineMessage, messageParams);

            Button retry = new Button(this);
            retry.setText("Retry");
            retry.setTextColor(Color.rgb(25, 35, 20));
            retry.setAllCaps(false);
            GradientDrawable buttonBg = new GradientDrawable();
            buttonBg.setColor(BRAND_GREEN);
            buttonBg.setCornerRadius(24);
            retry.setBackground(buttonBg);
            retry.setPadding(42, 8, 42, 8);
            retry.setOnClickListener(v -> retryLoading());
            panel.addView(retry, new LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT));

            offlineView = panel;
            root.addView(offlineView, new FrameLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        } else {
            offlineView.setVisibility(View.VISIBLE);
        }

        if (!hasNetworkConnection()) {
            offlineMessage.setText("No internet connection detected. Turn on Wi-Fi or mobile data, then tap Retry.");
        } else {
            offlineMessage.setText("SarkiData couldn't connect. Check your internet connection and tap Retry.");
        }
    }

    private void hideOffline() {
        if (offlineView != null) offlineView.setVisibility(View.GONE);
    }

    private void retryLoading() {
        if (!hasNetworkConnection()) {
            showOffline();
            return;
        }
        hideOffline();
        showSplash();
        webView.stopLoading();
        webView.loadUrl(HOME_URL);
    }

    @Override
    public void onBackPressed() {
        if (offlineView != null && offlineView.getVisibility() == View.VISIBLE) {
            if (webView != null && webView.canGoBack()) {
                hideOffline();
                webView.goBack();
            } else {
                super.onBackPressed();
            }
        } else if (webView != null && webView.canGoBack()) {
            webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (webView != null) {
            webView.destroy();
            webView = null;
        }
        super.onDestroy();
    }
}
